# 編輯器工具列 SVG 套組

來源：Tabler Icons https://github.com/tabler/tabler-icons
授權：MIT，完整條款見 LICENSE。下載日期：2026-10-25。

依截圖由左至右整理 27 個位置、26 個獨立 SVG，code 用於兩處。
這是同風格的功能／外觀對應，並非原始截圖圖示的逐像素複製。
第 22 個為即見即所得（mode-wysiwyg.svg），第 23 個為即時渲染（mode-instant-render.svg）。這兩個 SVG 依提供的截圖重畫，保留直立圓角方框、A 字與閃電外觀，並非 Tabler 原生圖示。其餘圖示來自 Tabler，授權條款僅適用於 Tabler 來源檔案。分隔直線是介面裝飾，不另列為圖示。

- svg/：獨立 SVG；24×24，stroke=currentColor，stroke-width=2
- preview.html：離線預覽與中文對照
- mapping.json：完整順序、名稱及各 SVG 來源 URL
- sprite.svg：SVG symbol 集合

使用方式：直接匯入 SVG，或將 SVG 內容內嵌至 HTML 以繼承 currentColor。
外部 img 的顏色不會繼承頁面 currentColor，需改用 inline SVG。
Sprite 範例：<svg width="24" height="24"><use href="sprite.svg#bold"/></svg>
外部 sprite 建議透過 HTTP 開啟，以避免瀏覽器 file:// 限制。
